import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, Text, View, TextInput, TouchableOpacity, ScrollView, Alert, Image, Linking, ActivityIndicator 
} from 'react-native';

// NOTA: Para una conexión en vivo profesional entre ambas apps, se recomienda integrar Firebase Firestore.
// Aquí usamos un almacenamiento local sincronizado conceptualmente para la estructura base en Expo Go.

const TARIFAS_FIJAS = {
  5: 2500, 10: 3500, 15: 5000, 20: 6500, 25: 7500, 
  30: 9000, 35: 10500, 40: 11500, 45: 13000, 50: 14500, 
  55: 16000, 60: 17500, 65: 19000, 70: 20000, 75: 21500, 
  80: 24000, 85: 24500, 90: 25500, 100: 26500
};

export default function AppCliente() {
  const [step, setStep] = useState('login'); // 'login', 'register', 'verify', 'dashboard'
  
  // Estados de Registro
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [documento, setDocumento] = useState('');
  const [pais, setPais] = useState('Guyana');
  const [telefonoReg, setTelefonoReg] = useState('');
  const [codigoAcceso, setCodigoAcceso] = useState('');
  
  // Credenciales de Acceso
  const [telefonoLogin, setTelefonoLogin] = useState('');
  const [claveLogin, setClaveLogin] = useState('');
  const [nuevaClave, setNuevaClave] = useState('');

  // Dashboard y Calculadora
  const [tasaDia, setTasaDia] = useState(940.00); // Puedes cambiar este valor manualmente aquí o vía Admin
  const [montoUSD, setMontoUSD] = useState('10');
  const [bancoDestino, setBancoDestino] = useState('');
  const [cedulaDestino, setCedulaDestino] = useState('');
  const [tlfDestino, setTlfDestino] = useState('');

  const ADMIN_WHATSAPP = '+5927577576';
  const CODIGO_SECRETO_ADMIN = '0403Michelle2106';

  const enviarWhatsAppOculto = (mensaje) => {
    const url = `https://wa.me/${ADMIN_WHATSAPP.replace('+', '')}?text=${encodeURIComponent(mensaje)}`;
    Linking.openURL(url).catch(() => Alert.alert("Error", "No se pudo conectar con WhatsApp"));
  };

  const registrarSolicitud = () => {
    if(!nombre || !apellido || !documento || !telefonoReg) {
      Alert.alert("Atención", "Por favor completa todos los campos del formulario.");
      return;
    }
    const mensaje = `🔔 NUEVA SOLICITUD DE REGISTRO - TRANSMICHELLE\n\nNombre: ${nombre} ${apellido}\nDoc: ${documento}\nPaís: ${pais}\nTeléfono: ${telefonoReg}`;
    enviarWhatsAppOculto(mensaje);
    Alert.alert("Solicitud Enviada", "Tus datos han sido enviados para verificación. Una vez aprobados, recibirás tu código de acceso.");
    setStep('verify');
  };

  const verificarCodigoAdmin = () => {
    if(codigoAcceso !== CODIGO_SECRETO_ADMIN) {
      Alert.alert("Error de Seguridad", "Código de verificación incorrecto. Solo es suministrado por la administración.");
      return;
    }
    setStep('createPassword');
  };

  const finalizarRegistroClave = () => {
    if(!telefonoLogin || !nuevaClave) {
      Alert.alert("Error", "Ingresa tu número y clave.");
      return;
    }
    const mensaje = `🔐 NUEVO USUARIO REGISTRADO Y CLAVE\nTeléfono: ${telefonoLogin}\nClave: ${nuevaClave}`;
    enviarWhatsAppOculto(mensaje);
    Alert.alert("¡Registro Exitoso!", "Ya puedes iniciar sesión en la aplicación.");
    setStep('login');
  };

  const iniciarSesion = () => {
    if(telefonoLogin && claveLogin) {
      setStep('dashboard');
    } else {
      Alert.alert("Error", "Ingrese número telefónico y clave válidos.");
    }
  };

  const procesarPagoTransferencia = () => {
    if(!bancoDestino || !cedulaDestino || !tlfDestino) {
      Alert.alert("Faltan datos", "Por favor llena los datos bancarios de destino.");
      return;
    }
    const gyDaneses = TARIFAS_FIJAS[parseInt(montoUSD)] || 0;
    const bolivares = gyDaneses > 0 ? (parseInt(montoUSD) * tasaDia) : 0;

    const mensaje = `💸 NUEVA ORDEN DE TRANSFERENCIA - TRANSMICHELLE\n\nCliente Tlf: ${telefonoLogin}\nMonto USD: $${montoUSD}\nPaga en GYD: ${gyDaneses} GYD\nRecibe en VES: ${bolivares} Bolívares\nBanco Destino: ${bancoDestino}\nCédula: ${cedulaDestino}\nTlf Destino: ${tlfDestino}`;
    enviarWhatsAppOculto(mensaje);
    Alert.alert("Proceso Iniciado", "El pago ya está en proceso. Puede tardar hasta media hora en realizarse.");
  };

  // --- PANTALLA 1: LOGIN ---
  if(step === 'login') {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.tituloHeader}>TRANSMICHELLE</Text>
        <Text style={styles.subHeader}>Transferencias seguras Guyana - Venezuela</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Número Telefónico de WhatsApp</Text>
          <TextInput style={styles.input} placeholder="Ej: +592..." keyboardType="phone-pad" value={telefonoLogin} onChangeText={setTelefonoLogin} placeholderTextColor="#888" />

          <Text style={styles.label}>Contraseña</Text>
          <TextInput style={styles.input} placeholder="********" secureTextEntry value={claveLogin} onChangeText={setClaveLogin} placeholderTextColor="#888" />

          <TouchableOpacity style={styles.botonDorado} onPress={iniciarSesion}>
            <Text style={styles.textoBotonNegro}>INICIAR SESIÓN</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setStep('register')} style={{marginTop: 15}}>
            <Text style={styles.linkText}>¿No estás registrado? Crea tu usuario aquí</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.whatsappButton} onPress={() => Linking.openURL(`https://wa.me/${ADMIN_WHATSAPP.replace('+', '')}`)}>
          <Text style={styles.textoBotonBlanco}>Atención al Cliente (WhatsApp)</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  // --- PANTALLA 2: REGISTRO FORMULARIO ---
  if(step === 'register') {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.tituloHeader}>REGISTRO DE CLIENTE</Text>
        <View style={styles.card}>
          <Text style={styles.label}>Nombre Completo</Text>
          <TextInput style={styles.input} value={nombre} onChangeText={setNombre} placeholderTextColor="#888" />

          <Text style={styles.label}>Apellido Completo</Text>
          <TextInput style={styles.input} value={apellido} onChangeText={setApellido} placeholderTextColor="#888" />

          <Text style={styles.label}>Cédula o Pasaporte</Text>
          <TextInput style={styles.input} value={documento} onChangeText={setDocumento} placeholderTextColor="#888" />

          <Text style={styles.label}>País</Text>
          <TextInput style={styles.input} value={pais} onChangeText={setPais} placeholderTextColor="#888" />

          <Text style={styles.label}>Número Telefónico para Código</Text>
          <TextInput style={styles.input} keyboardType="phone-pad" value={telefonoReg} onChangeText={setTelefonoReg} placeholderTextColor="#888" />

          <Text style={styles.label}>Adjuntar Selfi y Documento (Simulado)</Text>
          <TouchableOpacity style={styles.uploadBox}><Text style={{color: '#D4AF37'}}>Subir Fotos desde Galería</Text></TouchableOpacity>

          <TouchableOpacity style={styles.botonDorado} onPress={registrarSolicitud}>
            <Text style={styles.textoBotonNegro}>ENVIAR SOLICITUD</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setStep('login')} style={{marginTop: 15}}>
            <Text style={styles.linkText}>Volver al Inicio</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  // --- PANTALLA 3: VERIFICACIÓN DE CÓDIGO ---
  if(step === 'verify') {
    return (
      <View style={styles.containerCenter}>
        <View style={styles.card}>
          <Text style={styles.tituloHeader}>VERIFICACIÓN</Text>
          <Text style={styles.subHeader}>Introduce el código de acceso secreto enviado a tu WhatsApp por la administración.</Text>
          
          <TextInput style={styles.input} placeholder="Código secreto" value={codigoAcceso} onChangeText={setCodigoAcceso} placeholderTextColor="#888" />

          <TouchableOpacity style={styles.botonDorado} onPress={verificarCodigoAdmin}>
            <Text style={styles.textoBotonNegro}>VALIDAR CÓDIGO</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // --- PANTALLA 4: CREAR CLAVE FINAL ---
  if(step === 'createPassword') {
    return (
      <View style={styles.containerCenter}>
        <View style={styles.card}>
          <Text style={styles.tituloHeader}>CREAR CREDENCIALES</Text>
          <Text style={styles.label}>Número Telefónico</Text>
          <TextInput style={styles.input} placeholder="Tus dígitos" keyboardType="phone-pad" value={telefonoLogin} onChangeText={setTelefonoLogin} placeholderTextColor="#888" />

          <Text style={styles.label}>Nueva Clave de Acceso</Text>
          <TextInput style={styles.input} placeholder="Clave secreta" secureTextEntry value={nuevaClave} onChangeText={setNuevaClave} placeholderTextColor="#888" />

          <TouchableOpacity style={styles.botonDorado} onPress={finalizarRegistroClave}>
            <Text style={styles.textoBotonNegro}>LISTO - GUARDAR</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  // --- PANTALLA 5: DASHBOARD PRINCIPAL ---
  const gyDanesesCalculado = TARIFAS_FIJAS[parseInt(montoUSD)] || 0;
  const bolivaresCalculado = gyDanesesCalculado > 0 ? (parseInt(montoUSD) * tasaDia) : 0;

  return (
    <ScrollView contentContainerStyle={styles.containerDashboard}>
      <View style={styles.topBar}>
        <Text style={styles.brandTitle}>TRANSMICHELLE</Text>
        <View style={styles.tasaBadge}>
          <Text style={styles.tasaText}>Tasa: {tasaDia} VES/$</Text>
        </View>
      </View>

      <View style={styles.cardNotice}>
        <Text style={styles.noticeTitle}>⚠️ Información de Destino</Text>
        <Text style={styles.noticeDesc}>Por los momentos operamos estrictamente de Guyana a Venezuela. Para otros destinos, consulte directamente al soporte.</Text>
      </View>

      {/* CALCULADORA Y TARIFAS */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Calculadora de Transferencia</Text>
        <Text style={styles.label}>Seleccione / Escriba monto fijo permitido ($5 - $100):</Text>
        <TextInput style={styles.input} keyboardType="numeric" value={montoUSD} onChangeText={setMontoUSD} placeholderTextColor="#888" />

        <View style={styles.calcResultBox}>
          <Text style={styles.resultText}>Monto a transferir (USD): ${montoUSD}</Text>
          <Text style={styles.resultText}>Pagas en Guyana (GYD): {gyDanesesCalculado} GYD</Text>
          <Text style={styles.resultText}>Reciben en Venezuela (VES): {bolivaresCalculado.toFixed(2)} Bolívares</Text>
        </View>
      </View>

      {/* DATOS BANCARIOS MMG */}
      <View style={styles.cardBank}>
        <Text style={styles.sectionTitle}>Datos Bancarios de Pago (Guyana)</Text>
        <Text style={styles.bankInfo}>Método: MMG</Text>
        <Text style={styles.bankInfo}>Titular: ADRIANA AFANADOR</Text>
        <Text style={styles.bankInfo}>Número: 7577576</Text>
        <Text style={styles.bankNote}>Nota: Puede realizar el pago desde una agencia MMG, no es necesario poseer cuenta propia MMG.</Text>
      </View>

      {/* FORMULARIO DE ENVÍO */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>Detalles de Destino en Venezuela</Text>
        <TextInput style={styles.input} placeholder="Nombre del Banco" value={bancoDestino} onChangeText={setBancoDestino} placeholderTextColor="#888" />
        <TextInput style={styles.input} placeholder="Cédula de Identidad" value={cedulaDestino} onChangeText={setCedulaDestino} placeholderTextColor="#888" />
        <TextInput style={styles.input} placeholder="Número de Teléfono Móvil Pago Móvil" keyboardType="phone-pad" value={tlfDestino} onChangeText={setTlfDestino} placeholderTextColor="#888" />

        <TouchableOpacity style={styles.uploadBox}>
          <Text style={{color: '#D4AF37'}}>Adjuntar Capture de Pago (Galería)</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botonDorado} onPress={procesarPagoTransferencia}>
          <Text style={styles.textoBotonNegro}>REALIZAR Y ENVIAR PAGO</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.whatsappButton} onPress={() => Linking.openURL(`https://wa.me/${ADMIN_WHATSAPP.replace('+', '')}`)}>
        <Text style={styles.textoBotonBlanco}>Atención al Cliente</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: '#121212', padding: 20, justifyContent: 'center' },
  containerCenter: { flex: 1, backgroundColor: '#121212', padding: 20, justifyContent: 'center' },
  containerDashboard: { flexGrow: 1, backgroundColor: '#121212', padding: 15, paddingTop: 40 },
  tituloHeader: { fontSize: 26, fontWeight: 'bold', color: '#D4AF37', textAlign: 'center', marginBottom: 5 },
  subHeader: { fontSize: 14, color: '#CCCCCC', textAlign: 'center', marginBottom: 20 },
  card: { backgroundColor: '#1E1E1E', padding: 20, borderRadius: 10, borderWidth: 1, borderColor: '#333', marginBottom: 15 },
  cardBank: { backgroundColor: '#1A1A1A', padding: 20, borderRadius: 10, borderWidth: 1, borderColor: '#D4AF37', marginBottom: 15 },
  cardNotice: { backgroundColor: '#222', padding: 15, borderRadius: 8, borderLeftWidth: 4, borderLeftColor: '#D4AF37', marginBottom: 15 },
  noticeTitle: { color: '#D4AF37', fontWeight: 'bold', fontSize: 14 },
  noticeDesc: { color: '#AAA', fontSize: 12, marginTop: 4 },
  label: { color: '#D4AF37', fontSize: 13, marginBottom: 5, marginTop: 10 },
  input: { backgroundColor: '#2C2C2C', color: '#FFF', padding: 12, borderRadius: 6, marginBottom: 10, borderWidth: 1, borderColor: '#444' },
  botonDorado: { backgroundColor: '#D4AF37', padding: 15, borderRadius: 6, alignItems: 'center', marginTop: 15 },
  textoBotonNegro: { color: '#000', fontWeight: 'bold', fontSize: 16 },
  textoBotonBlanco: { color: '#FFF', fontWeight: 'bold', fontSize: 15 },
  linkText: { color: '#D4AF37', textAlign: 'center', marginTop: 10, textDecorationLine: 'underline' },
  whatsappButton: { backgroundColor: '#25D366', padding: 12, borderRadius: 6, alignItems: 'center', marginVertical: 10 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15, backgroundColor: '#1E1E1E', padding: 12, borderRadius: 8 },
  brandTitle: { color: '#D4AF37', fontSize: 18, fontWeight: 'bold' },
  tasaBadge: { backgroundColor: '#333', paddingVertical: 4, paddingHorizontal: 8, borderRadius: 4 },
  tasaText: { color: '#FFF', fontSize: 12, fontWeight: 'bold' },
  sectionTitle: { color: '#D4AF37', fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
  calcResultBox: { backgroundColor: '#252525', padding: 12, borderRadius: 6, marginTop: 10 },
  resultText: { color: '#FFF', fontSize: 13, marginVertical: 2 },
  bankInfo: { color: '#FFF', fontSize: 14, marginVertical: 2 },
  bankNote: { color: '#BBB', fontSize: 11, fontStyle: 'italic', marginTop: 8 },
  uploadBox: { borderWidth: 1, borderColor: '#D4AF37', borderStyle: 'dashed', padding: 15, borderRadius: 6, alignItems: 'center', marginVertical: 10, backgroundColor: '#181818' }
});
